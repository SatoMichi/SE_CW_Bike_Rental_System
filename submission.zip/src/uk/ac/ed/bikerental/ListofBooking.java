package uk.ac.ed.bikerental;
import java.util.ArrayList;
import java.util.List;

public class ListofBooking {
    protected static List<Booking> bookings = new ArrayList<>();
}
