package uk.ac.ed.bikerental;
import java.util.List;
import java.util.ArrayList;

public class ProviderList {
    protected static List<BikeProvider> providers = new ArrayList<BikeProvider>();
}
