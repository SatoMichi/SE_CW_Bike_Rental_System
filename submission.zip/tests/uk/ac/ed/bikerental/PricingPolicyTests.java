package uk.ac.ed.bikerental;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;


public class PricingPolicyTests {
    // You can add attributes here

    @BeforeEach
    void setUp() throws Exception {
        // Put setup here
    }
    
    // TODO: Write tests for pricing policies
}